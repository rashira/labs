from django.contrib import admin
from news.models import Articles

admin.site.register(Articles)
